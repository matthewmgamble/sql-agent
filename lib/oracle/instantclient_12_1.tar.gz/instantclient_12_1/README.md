# Oracle Instant Client

License on website: http://www.oracle.com/technetwork/licenses/instant-client-lic-152016.html
